$(document).ready(function ()
{
	   alert("Hello jQuery :-)");
});